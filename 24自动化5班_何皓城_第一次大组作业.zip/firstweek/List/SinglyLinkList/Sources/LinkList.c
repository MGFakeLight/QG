#include <stdio.h>
#include <stdlib.h>
//#include "LinkList.h"

typedef struct LinkList
{
    int data;                //本节点数据
    struct LinkList *next;     //下个节点地址
}LinkList;

LinkList *CreateNode(int input)    //创建新节点并传入数据
{
    LinkList *newnode=(LinkList*)malloc(sizeof(LinkList));   //分配动态内存
    if(newnode!=NULL)            //内存分配成功，配置节点
    {
        newnode->data=input;
        newnode->next=NULL;
        return newnode;         //返回新节点
    }
    else       //内存分配失败
    {
        printf("Fail to create new node");
        return NULL;
    }
}

void Assert(LinkList **head,int input)       //尾部插入新节点
{
    LinkList *temp=*head;
    if(temp==NULL)
    {
        *head=CreateNode(input);
        return;
    }
    while(temp->next!=NULL)
    {
        temp=temp->next;        //遍历链表直至尾部
    }
    temp->next=CreateNode(input);

}


void PrintLinkList(LinkList *head)      //打印链表
{
    LinkList *temp=head;
    while(temp!=NULL)
    {
        printf("%d\n",temp->data);
        temp=temp->next;
    }
}


