#ifndef LINKLIST_H
#define LINKLIST_H

typedef struct LinkList
{
    int data;                //本节点数据
    struct LinkList *next;     //下个节点地址
}LinkList;

LinkList* CreateNode(int input);
void Assert(LinkList* head,int input);
void PrintLinkList(LinkList *head);

#endif
