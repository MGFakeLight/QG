#include <stdio.h>
#include <stdlib.h>
//#include "LinkList.h"

typedef struct LinkList
{
    int data;   //本节点数据 
    struct LinkList *pre;      //上个节点地址      
    struct LinkList *next;     //下个节点地址
}LinkList;


LinkList *CreateNode(int input)    //创建新节点并传入数据
{
    LinkList *newnode=(LinkList*)malloc(sizeof(LinkList));   //分配动态内存
    if(newnode!=NULL)            //内存分配成功，配置节点
    {
        newnode->data=input;
        newnode->pre=NULL;
        newnode->next=NULL;
        return newnode;         //返回新节点
    }
    else       //内存分配失败
    {
        printf("Fail to create new node");
        return NULL;
    }
}

void Assert(LinkList **head,int input)       //尾部插入新节点
{
    LinkList* newnode=CreateNode(input);
    LinkList *temp=*head;
    if(temp==NULL)
    {
        *head=newnode;
        return;
    }
    while(temp->next!=NULL)
    {
        temp=temp->next;        //遍历链表直至尾部
    }
    temp->next=newnode;
    newnode->pre=temp;

}


void PrintLinkList(LinkList *head)      //打印链表
{
    LinkList *temp=head;
    while(temp->next!=NULL)
    {
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("%d\n",temp->data);      //遍历至最后一个节点，然后折返
    while(temp!=NULL)
    {
        printf("%d ",temp->data);
        temp=temp->pre;
    }
}



int main()
{
    LinkList* head=NULL;
    Assert(&head,1);
    Assert(&head,2);
    Assert(&head,3);
    Assert(&head,4);
    Assert(&head,5);
    Assert(&head,6);
    PrintLinkList(head);

    system("pause");
    return 0;
}